 <?php
 
session_start();
if($_SESSION["UserID"]==''){
header("location:index.php");
}
$filename=$_GET['f'];

$userdir=$_SESSION["UserID"]."/";

unlink($userdir.$filename);
header('location:list.php');

?>
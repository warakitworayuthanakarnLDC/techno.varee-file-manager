<head>
<meta charset='utf-8'>
<script>
function goBack() {
    window.history.back();
}
</script> 
<style>


.login-page {
  width: 360px;
  padding: 8% 0 0;
  margin: auto;
}
.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 360px;
  margin: 0 auto 100px;
  padding: 45px;
  text-align: center;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}
.form input {
  font-family: "sukhumvit_settext";
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}
.form button {
  font-family: "Roboto";
  text-transform: uppercase;
  outline: 0;
  background: #4CAF50;
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;
}
.form button:hover,.form button:active,.form button:focus {
  background: #43A047;
}
.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
  clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}
body {
  background: #76b852; /* fallback for old browsers */
  background: -webkit-linear-gradient(right, #76b852, #8DC26F);
  background: -moz-linear-gradient(right, #76b852, #8DC26F);
  background: -o-linear-gradient(right, #76b852, #8DC26F);
  background: linear-gradient(to left, #76b852, #8DC26F);
  font-family: "sukhumvit_settext", sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;      
}

</style>
</head>
<?

$servername = "localhost";
$username = "root";
$password = "varee123";
$dbname = "wow";

$uid=$_POST['uid'];
$pid=$_POST['pid'];

if (!$uid OR !$pid){?>
<div class='login-page'>
<div class='form'>
 กรุณาใส่ข้อมูลให้ถูกต้อง 
  <button onclick="goBack()">Go Back</button>
</div></div>
<?
exit();

}





$path = "/var/www/html/$uid";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$ckql = "select * from techno where student='$uid'";
$result = $conn->query($ckql);
if ($result->num_rows > 0) {
?>
<div class='login-page'>
<div class='form'>
ข้อมูลซ้ำกับผู้ใช้คนอื่น
  <button onclick="goBack()">Go Back</button>
</div></div>

<?
exit();
}



$sql = "INSERT INTO techno (id, student, password)VALUES (NULL, '$uid', '$pid')";

if ($conn->query($sql) === TRUE) {

echo "<div class='login-page'>";
 echo " <div class='form'>";
  
  //	mkdir($path, 0777);
  	mkdir ($path); chmod ($path, 0775);

    echo "ลงทะเบียนเสร็จสิ้น <br><br>";
    echo "เว็บไซต์ของคุณคือ http://techno.varee.ac.th/$uid";
    ?><br><br>
   <a href='http://techno.varee.ac.th/'>กลับไปหน้า login</a>
   <? 
echo "    </div></div>";
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>

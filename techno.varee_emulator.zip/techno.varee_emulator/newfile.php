<?php
session_start();
if($_SESSION["UserID"]==''){
header("location:index.php");
}


$filename=$_GET['fname'];

$userdir=$_SESSION["UserID"]."/";

$myfile = fopen($userdir.$filename, "w") ;


header('location:list.php');



 ?>
<?

$servername = "localhost";
$username = "vcis";
$password = "vcis2017";
$dbname = "vcis";


$tb = $_POST['tableName'];
$num_fields = $_POST['num_fields'];
//echo $tb."<br>";

for ($i=1;$i<=$num_fields;$i++){
$fname = $_POST['fieldName'.$i];
$tp = $_POST['tp'.$i];
$lng = $_POST['lng'.$i];
if ($lng){
$lng = "(".$lng.")";
}else{
$lng = "(10)";
}

$ai = $_POST['ai'.$i];
if ($ai){
$ai = "  AUTO_INCREMENT PRIMARY KEY ";
}
if ($i<>1){
$en=',';
}
$sqlf.= $en.$fname." ".$tp." ".$lng." NOT NULL ".$ai;
//echo $fname.$tp. $lng .$ai.    "<br>";

}
$sql0 = "CREATE TABLE IF NOT EXISTS $tb (";
$sqlz= ") DEFAULT CHARSET=utf8";


$sql = $sql0.$sqlf.$sqlz;

//CREATE TABLE mmasdfm ( mid INT(2 ) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
//              uss varchar(3) NOT NULL , pwd text NOT NULL  , eem date NOT NULL)  DEFAULT CHARSET=utf8;

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}





if ($conn->query($sql) === TRUE) {
    echo $sql;
} else {
    echo "Error creating table: " . $conn->error ."<br>".$sql;;
}






?>
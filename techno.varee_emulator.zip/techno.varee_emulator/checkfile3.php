<?php 
$id=$_GET['id'];
$filename='work3.php';

$fname=$id."/".$filename;
$file = file($fname); 

//$text0=htmlspecialchars(file_get_contents($fname));
//$text0=htmlspecialchars(addslashes($text0));
//$txt =addslashes($text0);
$all = file_get_contents($fname);

$lines = preg_split('/\n/', $all);

foreach ($lines as $line) { 

 $txt .=$line; 

} 

?>
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">


  <script type="text/javascript" src="//code.jquery.com/jquery-2.0.2.js"></script>
 <link rel="stylesheet" type="text/css" href="/css/result-light.css">
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/ace/1.1.01/ace.js"></script>
    
  

  <style type="text/css">
    #editor {
    /** Setting height is also important, otherwise editor wont showup**/
    height: 500px;
    width:100%;
 
         font-family: "Monaco", "Menlo", "Ubuntu Mono", "Droid Sans Mono", "Consolas", monospace !important;
    font-size: 20px !important;
    font-weight: 400 !important;
    letter-spacing: 0 !important;
 margin-left: 0px;
  margin-top: 0px;
  clear: both;
    display: table;
    

}
.heading{
 background: #76b852; 
 width: 100%;
 font-size=20px;

}

.bwbtn {
width: 120px;
    height: 30px;
    margin-left: 50px;
}

.iframe{
margin-right: 0px;
margin-left: 500px;
margin-top: 0px;
 float: right;
}

  </style>

  <title>edit mode</title>


<script type='text/javascript'>//<![CDATA[
$(function(){
   var textarea = $('#content');
    var textarea1 = document.getElementById('a1');
    var safetext = textarea1.value;

   var editor = ace.edit("editor");
   editor.setTheme("ace/theme/twilight");
   	  editor.session.setUseWrapMode(true);
  
   editor.getSession().setMode("ace/mode/php");
	
  	editor.setValue(safetext);
  
	editor.gotoLine(1);

   editor.getSession().on('change', function () {
       textarea.val(editor.getSession().getValue());
   });

   textarea.val(editor.getSession().getValue());

 
});//]]> 



</script>

  
</head>

<body>
  <div class="container">
    <div class="panel panel-default">
       
        <div class="panel-body">
            <div class="row">
                <h4 class='heading'>editing : <?=$fname?></h4>
 <tr><td> 
                <div class="col-md-6">
                    <div id="editor"></div>
                   
                    
                </div>

            
    <form action='updatefile.php' method="POST" enctype='application/x-www-form-urlencoded' id='xx'>
   <input type='hidden' name='fname' value='<?=$filename?>'>
    <input type='submit' name='Submit' class='bwbtn' value='Save'>
    </form>

<textarea style="display:none;" rows="10" cols="100" name="content" id="content" form='xx'>

</textarea>
<?php echo "<textarea  style='display:none;'  id='a1' Name=\"update\" cols=\"70\" rows=\"30\" autofocus='autofocus'>"; 

 echo $txt; 

echo "</textarea>";
?>


                </div>
            </div>
        </div>
    </div>


</body>

</html>


?>
<?
session_start();
$filename=$_POST['fname'];
$text = $_POST['content']; 

if($_SESSION["UserID"]==''){
header("location:index.php");
}
$userdir=$_SESSION["UserID"]."/";
$fname=$userdir.$filename;

//echo $text."<br>";
//echo $fname;


if($_POST['Submit']){ 
$open = fopen($fname,"w+"); 

fwrite($open, $text); 
fclose($open); 
}
header('location:list.php');


?>
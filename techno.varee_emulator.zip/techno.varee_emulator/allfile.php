<?php
$id=$_GET['id'];
?>
<iframe src=checkfile.php?id=<?=$id;?> width=600 height=500></iframe>
<iframe src=checkfile2.php?id=<?=$id;?> width=600 height=500></iframe>
<iframe src=checkfile3.php?id=<?=$id;?> width=600 height=500></iframe>
<iframe src=checkfile4.php?id=<?=$id;?> width=600 height=500></iframe>
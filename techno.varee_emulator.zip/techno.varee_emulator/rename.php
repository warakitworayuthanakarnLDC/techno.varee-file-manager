 <style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
 
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    font-size: 20px;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 20px;
}

input[type=submit]:hover {
    background-color: #45a049;
}
.cancel:hover{
background-color: #45a049;
}
.cancel{
   width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 20px;
}


div {
width:49%;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    width:500px;
    margin-left:30%;
}
 </style>
 <?php
 
session_start();
if($_SESSION["UserID"]==''){
header("location:index.php");
}
$userdir=$_SESSION["UserID"]."/";


$oldname=$_GET['oldname'];

echo "<div>";
echo "<h2 >Rename</h2>";
echo "<form action=rename1.php>";
echo "Old file:<input  disabled type='text' name='oldd' value='$oldname'><br>";
echo "New file:<input type='text' name='new'><br>";
echo "<input type='hidden' name='old' value='$oldname'><br>";
echo "<input type=submit value=Rename>"; ?>

<input type="button" class="cancel" name="cancel" value="Cancel" onClick="window.history.back();" />
 




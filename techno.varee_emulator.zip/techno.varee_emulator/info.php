<?php

echo    phpinfo();
    
    ?>

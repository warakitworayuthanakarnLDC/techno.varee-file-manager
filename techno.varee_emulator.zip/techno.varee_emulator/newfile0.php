<script type="text/javascript">
function prompt_box()
{
var naam=prompt("Filename:","Enter file name")
document.location = 'newfile.php?fname=' + naam;
}
</script>


<button type="button" id="setc" onclick='prompt_box()'>Creat new file</button>
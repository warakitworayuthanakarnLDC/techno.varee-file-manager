<style>
table, th, td {
    border: 1px solid eeeeee;
    border-collapse: collapse;
}
</style>
<meta charset="utf-8">
<form id="create_table_form_minimal" method="post" >
<fieldset>
    <legend>
<img src="http://techno.varee.ac.th/phpmyadmin/themes/dot.gif" title="" alt="" class="icon ic_b_newtbl">Create table    </legend>
    <input name="db" value="vcis" type="hidden"><input name="token" value="13bafe3b2c9c7d2114d7ec322247d75f" type="hidden">    <div class="formelement">
        ชื่อ:
        <input name="tableName" maxlength="64" size="30" type="text">
    </div>
    <div class="formelement">
        Number of Field:
        <input name="num_fields" size="2" type="text">
    </div>
    <div class="clearfloat"></div>
</fieldset>
<fieldset class="tblFooters">
    <input value="ลงมือ" type="submit">
</fieldset>
</form>

<?
$num_fields = $_POST['num_fields'];
$tableName=$_POST['tableName'];
if ($num_fields){

?>
 <form id='creat_tb' method="post" action='createdb.php' >
 <table border='1' width='60%'>
 <?
 for ($i=1;$i<=$num_fields;$i++){
 
 
 
 ?>
 <tr><td width='20'> Field <?=$i?> </td>
 <td width='20'> ชื่อ <input type="text" name="fieldName<?=$i?>"></td>
 <td width='30'> ชนิด <select name="tp<?=$i?>" form="creat_tb">
  <option value="int">INT</option>
  <option value="varchar">VARCHAR</option>
  <option value="text">TEXT</option>
  <option value="date">DATE</option>
</select></td>
 <td width='20'>ความยาว <input type="text" name="lng<?=$i?>"></td>
<td width='30'> Auto_increment<input type="checkbox" name="ai<?=$i?>" value="1"></td>
  </tr>
  
  <?}?>
  
  </table>
  <input type='hidden' name='num_fields' value='<?=$num_fields?>'>
  <input type='hidden' name='tableName' value='<?=$tableName?>'>
  
   <input type='submit' value='Submit'>
</form> 


<?
}
?>
<?php
session_start();
$userdir=$_SESSION["UserID"]."/";
$foldr= $userdir."images";
mkdir($foldr	0777);
?>
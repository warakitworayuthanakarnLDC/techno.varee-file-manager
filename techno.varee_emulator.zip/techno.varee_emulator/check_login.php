<?php
	session_start();
	mysql_connect("localhost","root","varee123");
	mysql_select_db("wow");
	$strSQL = "SELECT * FROM techno WHERE student = '".mysql_real_escape_string($_POST['txtUsername'])."' 
	and password = '".mysql_real_escape_string($_POST['txtPassword'])."'";
	$objQuery = mysql_query($strSQL);
	$objResult = mysql_fetch_array($objQuery);
	if(!$objResult)
	{
			echo "Username or Password Incorrect!";
			header("location:index.php");
	}
	else
	{
			$_SESSION["UserID"] = $objResult["student"];
			//$_SESSION["Status"] = $objResult["Status"];

			session_write_close();
			
			
				header("location:list.php");
			
	}
	mysql_close();
?>

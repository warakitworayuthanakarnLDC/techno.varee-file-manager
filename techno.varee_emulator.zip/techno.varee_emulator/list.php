<meta charset="utf-8">
<link href="https://fonts.googleapis.com/css?family=Kanit" rel="stylesheet"> 
<script>
/* Script written by Adam Khoury @ DevelopPHP.com */
/* Video Tutorial: http://www.youtube.com/watch?v=EraNFJiY0Eg */
function _(el){
	return document.getElementById(el);
}
function uploadFile(){
	var file = _("file1").files[0];
	// alert(file.name+" | "+file.size+" | "+file.type);
	var formdata = new FormData();
	formdata.append("file1", file);
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", progressHandler, false);
	ajax.addEventListener("load", completeHandler, false);
	ajax.addEventListener("error", errorHandler, false);
	ajax.addEventListener("abort", abortHandler, false);
	ajax.open("POST", "list.php");
	ajax.send(formdata);
}
function progressHandler(event){
	_("loaded_n_total").innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
	var percent = (event.loaded / event.total) * 100;
	_("progressBar").value = Math.round(percent);
	_("status").innerHTML = Math.round(percent)+"% uploaded... please wait";
}
function completeHandler(event){
	_("status").innerHTML = "Upload Complete";
	_("progressBar").value = 0;
	
	window.location.replace("list.php");
}
function errorHandler(event){
	_("status").innerHTML = "Upload Failed";
}
function abortHandler(event){
	_("status").innerHTML = "Upload Aborted";
}
</script>
<style>


.myButton {
    background:url(http://techno.varee.ac.th/00001/sl.png) no-repeat;
    cursor:pointer;
    width: 200px;
    height: 100px;
    border: none;
}

.head {
 background: #76b852; 

}
body {
font-family: 'Kanit', sans-serif;
  margin-top:0px;
margin-right:0px;
margin-left:0px;
margin-bottom:0px;
  background: #ffffff; /* fallback for old browsers */
 
  
}
th {
color:#fff;
}

.crbtn {
width: 120px;
    height: 30px;
    margin-left: 200px;
}
.bwbtn {
width: 200;
    height: 1000px;
    margin-left: 200px;
}

.btupld{
	font-weight: bold;
    width: 100%;
    background-color: #cccccc;
    color: white;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    border: 15px solid;
    border-color: #cccccc;

}

</style>
<?php
session_start();
if ($_SESSION["chngdir1"]==''){
$chngdir = $_GET['d']."/";
$_SESSION["chngdir1"] = $chngdir;

session_write_close();
}

$chngdir=$_SESSION["chngdir1"];
$userdir=$_SESSION["UserID"]."/";
if($_SESSION["UserID"]==''){
header("location:index.php");
}



$userdir=$userdir.$chngdir;

function listdir($currentdir){
    $dir = opendir($currentdir);
    $file = readdir($dir);
    $i=0;   
    do {
        
        if(($i % 2) == 0){
        $cr = "#F2F2F2";
        }else{
          
        $cr = "#FFFFFF";
        
        }
        
        
        if (is_dir($currentdir."/".$file) && $file != "." && $file != ".."){
            listdir($currentdir."/".$file);
            echo "<tr bgcolor=$cr><td><img width='10' src='folder.png'>$file "."</td><td></td><td></td></tr>";
        } else if($file != "." && $file != "..") {
        $i++;
       $lastModified = date('d/m/Y, H:i:s',filemtime($currentdir.$file));
        $fsize=filesize($currentdir.$file);
        
        if ($fsize>=1000000){
        $fsize= round($fsize/1000000)."MB";
        
        }else  if ($fsize>=1000){
         $fsize=round($fsize/1000) ." KB";
        }else{
         $fsize=round($fsize)." Byte";
        }
        
        
            echo  "<tr bgcolor=$cr><td><a href='http://techno.varee.ac.th/$currentdir$file'><img width='10' src='file.png'>$file </a>"."</td><td>".$fsize."</td><td>".$lastModified."</td><td align=center><a href='editfile.php?f=$file'><img title='Edit' width=20 src='https://cdn4.iconfinder.com/data/icons/simplicio/128x128/file_edit.png'></a>&nbsp;&nbsp;<a href='rename.php?oldname=$file'><img  title='Rename' src='https://cdn4.iconfinder.com/data/icons/aami-web-internet/64/aami18-59-128.png' width='20'></a>&nbsp;&nbsp;<a href='deletefile.php?f=$file' onclick='return confirm(\"ยืนยันการลบไฟล์?\");'><img title='Delete' src='http://techno.varee.ac.th/00001/70287.png' width=20></a></td></tr>";
        } else {
            continue;
        }
    } while($file = readdir($dir));
  
    closedir($dir); 
}


?>
<div class='head'>
<table>
<tr valign="center">
<td valign="center"><font size="5"> <img src='http://techno.varee.ac.th/00001/user-128.png' width='30'> <?=$userdir;?></font></td>
<td>|<a href="changPW.php"> <img src='http://techno.varee.ac.th/00001/ec470ca.png' width='30'></a> | <a href="logout.php"><img width='30' src='http://techno.varee.ac.th/00001/59399.png' ></a></td>
</tr>
</table>
</div>

<form id="upload_form"  method="post" enctype="multipart/form-data">
    
   <div >
   <label for="file1" class='.btupld'>Select File</label>
   <input type="file"  name="file1" id="file1"  style="width:200px">
   
   </div>
     <input type="hidden" name="d" value="<?=$userdir;?>">
    <img width='100' src='http://techno.varee.ac.th/00001/up.png' onclick="uploadFile()" >
      <progress id="progressBar" value="0" max="100" style="height:30px;width:300px;"></progress>
<h3 id="status"></h3>
  <p id="loaded_n_total"></p>
</form>

<script type="text/javascript">
function prompt_box()
{
var naam=prompt("Enter Filename: โปรดระวังการตั้งชื่อไฟล์ซ้ำไฟล์เดิม ทำให้ไฟล์เดิมโดนลบ")
if (naam){
document.location = 'newfile.php?fname=' + naam;
}
}

function inputnewname(nme){
var nme=prompt("Enter New Filename: โปรดระวังการตั้งชื่อไฟล์ซ้ำไฟล์เดิม ทำให้ไฟล์เดิมโดนลบ")
if (nme){
document.location = 'rename.php?newname=' + nme;
return nme;
}


}
</script>
<div><button class='crbtn' type="button" id="setc" onclick='prompt_box()'>Creat new file</button>
</div>
<?



echo '<table align=center width=70% cellspacing=0> ';
echo '<tr bgcolor="#045FB4"><th align=left width="30%">ชื่อไฟล์</th><th align=left width="20%">ขนาดไฟล์(byte)</th><th align=left width="30%">วันที่อับโหลด</th><th>จัดการ</th></tr>';
listdir($userdir); //change to your directory
echo '</table>';
//echo $currentdir;


$myfile=$userdir.$_FILES["file1"]["name"];
$fileTmpLoc = $userdir.$_FILES["file1"]["tmp_name"];
//$fileName =      $_FILES["file1"]["name"];

//if(move_uploaded_file($fileTmpLoc, "test_uploads/$fileName")){
if ($myfile=='') { // if file not chosen
    echo "ERROR: Please browse for a file before clicking the upload button.";
    exit();
}


if(move_uploaded_file($_FILES["file1"]["tmp_name"],$myfile))

{
echo "Copy/Upload Complete";
?>
<?}


?>

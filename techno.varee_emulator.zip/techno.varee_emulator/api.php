<?php
header('Content-Type: application/json');

$t=$_GET["temp"];

$myObj->result = $t;


$myJSON = json_encode($myObj);

echo $myJSON;


?>
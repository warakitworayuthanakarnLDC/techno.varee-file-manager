<?php

session_start();

if (!$_SESSION['UserID']) 
{
    header("location:index.php");
}
$password1 = $_POST['newPassword'];
if($password1<>""){

$dbcon = mysqli_connect('localhost', 'root', 'varee123', 'wow') or die(mysqli_error($dbcon));

//$password1 = mysqli_real_escape_string($dbcon, $_POST['newPassword']);
$password2 = $_POST['confirmPassword'];
$username = $_SESSION['UserID'];

if ($password1 <> $password2)
{
    echo "your passwords do not match";
    exit();
}
else if (mysqli_query($dbcon, "UPDATE techno SET password='$password1' WHERE student='$username'"))
{
    echo "You have successfully changed your password.";
    header("location:index.php");
}
else
{
    mysqli_error($dbcon);
}
mysqli_close($dbcon);
}
?>
<meta charset="utf-8">
<form action="changPW.php" method="post" enctype="multipart/form-data">
    change password : <?=$_SESSION['UserID'];?><br>
<table>  <tr>
  <td>รหัสผ่านใหม่</td><td><input type="text"  name="newPassword" ></td>
   </tr><tr>
    <td>รหัสผ่านใหม่อีกครั้ง</td><td><input type="text"  name="confirmPassword" ></td>
</tr></table>
    <input type="submit" value="Change" name="submit">
</form>

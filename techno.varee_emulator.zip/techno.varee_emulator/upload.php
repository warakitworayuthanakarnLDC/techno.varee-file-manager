<form action="upload.php" method="post" enctype="multipart/form-data">
    Select file to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="hidden" name="d" value="techno2">
    <input type="submit" value="Upload" name="submit">
</form>

<?php

$dir = $_GET['d']."/";


$target_dir = $dir;

$myfile="techno22/".$_FILES["fileToUpload"]["name"];


if(move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$myfile))

{
echo "Copy/Upload Complete";

}


?>